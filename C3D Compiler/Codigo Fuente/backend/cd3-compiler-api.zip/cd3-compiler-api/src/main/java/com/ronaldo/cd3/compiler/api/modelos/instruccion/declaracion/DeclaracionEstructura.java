package com.ronaldo.cd3.compiler.api.modelos.instruccion.declaracion;

import com.ronaldo.cd3.compiler.api.enums.OperadorCuarteta;
import com.ronaldo.cd3.compiler.api.modelos.contexto.Contexto;
import com.ronaldo.cd3.compiler.api.modelos.cuarteta.ListaCuartetas;
import com.ronaldo.cd3.compiler.api.modelos.expresion.Expresion;
import com.ronaldo.cd3.compiler.api.modelos.expresion.LiteralStructura;
import com.ronaldo.cd3.compiler.api.modelos.semantica.reglas.Reglas;
import com.ronaldo.cd3.compiler.api.modelos.tabla.simbolos.SimboloVariable;
import com.ronaldo.cd3.compiler.api.modelos.tipos.Tipo;
import com.ronaldo.cd3.compiler.api.modelos.tipos.TipoArreglo;
import com.ronaldo.cd3.compiler.api.modelos.tipos.TipoStructura;
import java.util.ArrayList;
import java.util.List;

/**
 *
 * @author ronaldo
 */
public class DeclaracionEstructura extends Declaracion {

    private final Reglas reglas = new Reglas();
    private final List<Expresion> valoresIniciales;
    private final Expresion valorExpresion;

    public DeclaracionEstructura(List<Expresion> valoresIniciales, Expresion valorExpresion, String tipoDato, String id, int fila, int columna) {
        super(tipoDato, id, fila, columna);
        this.valoresIniciales = valoresIniciales;
        this.valorExpresion = valorExpresion;

    }

    public List<Expresion> getValoresIniciales() {
        return valoresIniciales;
    }

    public Expresion getValorExpresion() {
        return valorExpresion;
    }

    @Override
    public void verificarSemantica(Contexto contexto) {
        Tipo tipo = reglas.resolverTipo(contexto, tipoDato, fila, columna);
        if (reglas.esError(tipo)) {
            return;
        }
        if (!(tipo instanceof TipoStructura)) {
            contexto.agregarError(fila, columna, tipoDato,
                    "El tipo '" + tipoDato + "' de la declaración '" + id + "' no es una estructura ni una clase");
            return;
        }
        TipoStructura estructura = (TipoStructura) tipo;

        if (valorExpresion != null) {
            valorExpresion.verificarSemantica(contexto);
        }
        if (valoresIniciales != null) {
            for (Expresion valor : valoresIniciales) {
                valor.verificarSemantica(contexto);
            }
        }

        SimboloVariable variable = reglas.registrarVariable(contexto, id, tipo, fila, columna);
        if (variable == null) {
            return;
        }

        if (valorExpresion != null && !reglas.esAsignable(tipo, valorExpresion.getTipo())) {
            contexto.agregarError(valorExpresion.getFila(), valorExpresion.getColumna(), id,
                    "No se puede asignar un valor de tipo '" + valorExpresion.getTipo()
                    + "' a '" + id + "' de tipo '" + tipoDato + "'");
        }

        if (valoresIniciales != null) {
            if (estructura.esClase()) {
                contexto.agregarError(fila, columna, id,
                        "La clase '" + tipoDato + "' se inicializa con 'novus' o 'null', no con { }");
            } else if (valoresIniciales.size() > estructura.getAtributos().size()) {
                contexto.agregarError(fila, columna, id,
                        "Demasiados valores iniciales para la estructura '" + id + "'");
            }
        }
    }

    @Override
    public String generarCuartetas(Contexto contexto, ListaCuartetas cuartetas) {
        Tipo tipo = reglas.resolverTipo(contexto, tipoDato, fila, columna);
        if (reglas.esError(tipo) || !(tipo instanceof TipoStructura)) {
            return null;
        }
        TipoStructura estructura = (TipoStructura) tipo;
        cuartetas.registrarTipoVariableDeclarada(id, tipo);
        for (String nombreAtributo : estructura.getAtributos().keySet()) {
            cuartetas.registrarTipoVariable(id + "." + nombreAtributo,
                    estructura.getTipoAtributo(nombreAtributo));
            cuartetas.registrarTipoVariable(id + "_" + nombreAtributo,
                    estructura.getTipoAtributo(nombreAtributo));
        }
        if (valorExpresion != null) {
            String dirValor = valorExpresion.generarCuartetas(contexto, cuartetas);
            cuartetas.agregar(OperadorCuarteta.ASIGNACION, dirValor,
                    null, id, fila, columna);
            return null;
        }
        if (valoresIniciales != null) {
            int indice = 0;
            for (String nombreAtributo : estructura.getAtributos().keySet()) {
                if (indice >= valoresIniciales.size()) {
                    break;
                }
                Expresion valor = valoresIniciales.get(indice++);
                emitirInicializacionCampo(contexto, cuartetas,
                        id + "." + nombreAtributo,
                        estructura.getTipoAtributo(nombreAtributo),
                        valor, fila, columna);
            }
        }
        return null;
    }

    private void emitirInicializacionCampo(Contexto contexto, ListaCuartetas cuartetas,
            String destino, Tipo tipoCampo, Expresion valor, int fila, int columna) {
        cuartetas.registrarTipoVariable(destino, tipoCampo);
        if (tipoCampo instanceof TipoArreglo) {
            cuartetas.registrarTipoArreglo(destino,
                    ((TipoArreglo) tipoCampo).getTipoBase());
        }
        if (valor instanceof LiteralStructura) {
            if (tipoCampo instanceof TipoArreglo) {
                List<Expresion> elementos = listaValores(valor);
                int i = 0;
                for (Expresion elemento : elementos) {
                    emitirInicializacionCampo(contexto, cuartetas,
                            destino + "[" + i + "]",
                            ((TipoArreglo) tipoCampo).getTipoBase(),
                            elemento, fila, columna);
                    i++;
                }
                return;
            }
            if (tipoCampo instanceof TipoStructura) {
                TipoStructura sub = (TipoStructura) tipoCampo;
                List<Expresion> subValores = listaValores(valor);
                int indice = 0;
                for (String subAtributo : sub.getAtributos().keySet()) {
                    if (indice >= subValores.size()) {
                        break;
                    }
                    emitirInicializacionCampo(contexto, cuartetas,
                            destino + "." + subAtributo,
                            sub.getTipoAtributo(subAtributo),
                            subValores.get(indice++), fila, columna);
                }
                return;
            }
        }
        String dirValor = valor.generarCuartetas(contexto, cuartetas);
        if (dirValor != null) {
            cuartetas.agregar(OperadorCuarteta.ASIGNACION, dirValor,
                    null, destino, fila, columna);
        }
    }

    private List<Expresion> listaValores(Expresion valor) {
        if (valor instanceof LiteralStructura) {
            List<Expresion> valores = ((LiteralStructura) valor).getValores();
            if (valores != null) {
                return valores;
            }
            return new ArrayList<>();
        }
        List<Expresion> resultado = new ArrayList<>();
        resultado.add(valor);
        return resultado;
    }

}
