package com.ronaldo.cd3.compiler.api.services.generador.riscv;

import com.ronaldo.cd3.compiler.api.enums.OperadorCuarteta;
import com.ronaldo.cd3.compiler.api.enums.TipoDato;
import com.ronaldo.cd3.compiler.api.enums.TipoOperando;
import com.ronaldo.cd3.compiler.api.modelos.cuarteta.ListaCuartetas;
import com.ronaldo.cd3.compiler.api.modelos.ir.AmbienteIR;
import com.ronaldo.cd3.compiler.api.modelos.ir.EmisorIR;
import com.ronaldo.cd3.compiler.api.modelos.ir.operando.Operando;
import com.ronaldo.cd3.compiler.api.modelos.ir.operando.OperandoAtributo;
import com.ronaldo.cd3.compiler.api.modelos.ir.operando.OperandoIndice;
import com.ronaldo.cd3.compiler.api.modelos.ir.operando.OperandoLiteral;
import com.ronaldo.cd3.compiler.api.modelos.ir.operando.OperandoThis;
import com.ronaldo.cd3.compiler.api.modelos.ir.runtime.RuntimeZ;
import com.ronaldo.cd3.compiler.api.modelos.tabla.simbolos.SimboloParametro;
import com.ronaldo.cd3.compiler.api.modelos.tipos.Tipo;
import com.ronaldo.cd3.compiler.api.modelos.tipos.TipoArreglo;
import com.ronaldo.cd3.compiler.api.modelos.tipos.TipoStructura;
import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

/**
 * Emisor de ensamblador RISC-V (RV64) para el IR de Z. Traduce el modelo de
 * cuartetas a un texto .s usando una maquina de pila: cada operando nombrado
 * vive en una ranura del frame y cada operacion materializa su resultado en
 * una ranura temporal.
 */
public class EmisorRiscV implements EmisorIR {

    private static final int TAMAÑO_SLOT = 8;
    private static final int TAMAÑO_ENCABEZADO_FRAME = 16;
    private static final int TAMAÑO_BUFFER_CADENA = 256;

    private final AmbienteIR ambiente;
    private final ListaCuartetas cuartetas;

    private final StringBuilder cuerpo = new StringBuilder();
    private final StringBuilder unidad = new StringBuilder();

    private String unidadEnCurso;
    private boolean metodoEnCurso;
    private final Map<String, Integer> ranuras = new LinkedHashMap<>();
    private final Map<String, Integer> tamañosRanura = new LinkedHashMap<>();
    private final List<String> parametros = new ArrayList<>();
    private int siguienteOffset;

    private final List<Operando> parametrosPendientes = new ArrayList<>();

    public EmisorRiscV(AmbienteIR ambiente) {
        this.ambiente = ambiente;
        this.cuartetas = ambiente.getCuartetas();
    }

    public String getCuerpo() {
        return cuerpo.toString();
    }

    public void finalizar() {
        cerrarUnidad();
    }

    // ------------------------------------------------------------------
    // Estructura de unidades
    // ------------------------------------------------------------------

    private void abrirUnidad(String nombre) {
        unidadEnCurso = nombre;
        unidad.setLength(0);
        ranuras.clear();
        tamañosRanura.clear();
        siguienteOffset = 0;
        parametros.clear();
        parametrosPendientes.clear();
        metodoEnCurso = nombre != null
                && (nombre.startsWith("metodo_") || nombre.startsWith("constructor_"));
        if (metodoEnCurso) {
            asignarRanura("=this");
        }
        List<String> nombres = new ArrayList<>();
        if (cuartetas != null && nombre != null) {
            List<com.ronaldo.cd3.compiler.api.modelos.tabla.simbolos.SimboloParametro> lista
                    = cuartetas.parametrosDeFuncion(nombre);
            if (lista != null) {
                for (com.ronaldo.cd3.compiler.api.modelos.tabla.simbolos.SimboloParametro p : lista) {
                    nombres.add(p.getId());
                    asignarRanura(claveParametro(p.getId()));
                }
            }
        }
        parametros.addAll(nombres);
    }

    private void cerrarUnidad() {
        if (unidadEnCurso == null) {
            return;
        }
        int frame = alinear16(TAMAÑO_ENCABEZADO_FRAME + siguienteOffset);
        cuerpo.append(unidadEnCurso).append(":\n");
        cuerpo.append("    addi sp, sp, -").append(frame).append("\n");
        cuerpo.append("    sd ra, ").append(frame - 8).append("(sp)\n");
        cuerpo.append("    sd fp, ").append(frame - 16).append("(sp)\n");
        cuerpo.append("    addi fp, sp, ").append(frame).append("\n");
        if (metodoEnCurso) {
            cuerpo.append("    sd a0, ").append(offsetDeClave("=this")).append("(fp)\n");
        }
        for (int i = 0; i < parametros.size(); i++) {
            int registro = i + (metodoEnCurso ? 1 : 0);
            cuerpo.append("    sd a").append(registro).append(", ")
                    .append(offsetDeClave(claveParametro(parametros.get(i)))).append("(fp)\n");
        }
        cuerpo.append(unidad);
        cuerpo.append("__epilogo_").append(unidadEnCurso).append(":\n");
        if (unidadEnCurso.startsWith("constructor_")) {
            cuerpo.append("    ld a0, ").append(offsetDeClave("=this")).append("(fp)\n");
        }
        cuerpo.append("    ld t0, -16(fp)\n");
        cuerpo.append("    ld ra, -8(fp)\n");
        cuerpo.append("    addi sp, sp, ").append(frame).append("\n");
        cuerpo.append("    mv fp, t0\n");
        cuerpo.append("    ret\n\n");
        unidadEnCurso = null;
    }

    private void asegurarUnidad() {
        if (unidadEnCurso == null) {
            abrirUnidad("__global");
        }
    }

    // ------------------------------------------------------------------
    // Manejo de ranuras
    // ------------------------------------------------------------------

    private static int alinear16(int valor) {
        return (valor + 15) & ~15;
    }

    private static String claveParametro(String nombre) {
        return "OperandoParametro:" + nombre;
    }

    private static String clave(Operando operando) {
        if (operando instanceof com.ronaldo.cd3.compiler.api.modelos.ir.operando.OperandoThis) {
            return "=this";
        }
        return operando.getClass().getSimpleName() + ":" + operando.getTexto();
    }

    private int asignarRanura(String clave) {
        Integer existente = ranuras.get(clave);
        if (existente != null) {
            return existente;
        }
        siguienteOffset += TAMAÑO_SLOT;
        ranuras.put(clave, siguienteOffset);
        tamañosRanura.put(clave, TAMAÑO_SLOT);
        return siguienteOffset;
    }

    /**
     * Reserva una ranura de al menos {@code tamaño} bytes (para variables de
     * tipo struct por valor, que ocupan mas de un slot). Devuelve el offset
     * (positivo, relativo a fp) del inicio de la ranura.
     */
    private int asignarRanura(String clave, int tamaño) {
        Integer existente = ranuras.get(clave);
        if (existente != null) {
            return existente;
        }
        int reservado = (tamaño > TAMAÑO_SLOT) ? alinear8(tamaño) : TAMAÑO_SLOT;
        siguienteOffset += reservado;
        ranuras.put(clave, siguienteOffset);
        tamañosRanura.put(clave, reservado);
        return siguienteOffset;
    }

    private static int alinear8(int valor) {
        return (valor + 7) & ~7;
    }

    private String offsetDeClave(String clave) {
        int fin = asignarRanura(clave);
        int reservado = tamañosRanura.getOrDefault(clave, TAMAÑO_SLOT);
        return String.valueOf(-TAMAÑO_ENCABEZADO_FRAME - fin);
    }

    private String offset(Operando operando) {
        String clave = clave(operando);
        int fin = asignarRanura(clave, tamañoDeOperando(operando));
        return String.valueOf(-TAMAÑO_ENCABEZADO_FRAME - fin);
    }

    private int tamañoDeOperando(Operando operando) {
        Tipo tipo = (operando != null) ? operando.getTipo() : null;
        if (tipo instanceof TipoStructura && !((TipoStructura) tipo).esPorReferencia()) {
            return Math.max(TAMAÑO_SLOT, ((TipoStructura) tipo).getTamañoHeap());
        }
        return TAMAÑO_SLOT;
    }

    // ------------------------------------------------------------------
    // Operaciones del contrato EmisorIR
    // ------------------------------------------------------------------

    @Override
    public AmbienteIR getAmbiente() {
        return ambiente;
    }

    @Override
    public void emitirAsignacion(Operando destino, Operando origen) {
        asegurarUnidad();
        if (esStructPorValor(destino) && esStructPorValor(origen)) {
            int tamaño = ((TipoStructura) destino.getTipo()).getTamañoHeap();
            int palabras = min(tamaño / 8 + ((tamaño % 8 != 0) ? 1 : 0), 2);
            for (int i = 0; i < palabras; i++) {
                linea("ld t1, " + offsetPalabra(origen, i) + "(fp)");
                linea("sd t1, " + offsetPalabra(destino, i) + "(fp)");
            }
            return;
        }
        if (esDecimal(destino) && esEntero(origen)) {
            // conversion entero -> double antes de almacenar
            cargarValor(origen, "t1");
            linea("fcvt.d.w fa0, t1");
            linea("fmv.x.d t1, fa0");
            guardarValor(destino, "t1");
            return;
        }
        if (esEntero(destino) && esDecimal(origen)) {
            // conversion double -> entero
            cargarValor(origen, "t1");
            linea("fmv.d.x fa0, t1");
            linea("fcvt.w.d t1, fa0");
            guardarValor(destino, "t1");
            return;
        }
        cargarValor(origen, "t1");
        guardarValor(destino, "t1");
    }

    @Override
    public void emitirAritmetica(OperadorCuarteta operador, Operando izquierda,
            Operando derecha, Operando resultado) {
        asegurarUnidad();
        if (esDecimal(resultado)) {
            emitirAritmeticaDecimal(operador, izquierda, derecha, resultado);
            return;
        }
        cargarValor(izquierda, "t1");
        cargarValor(derecha, "t2");
        linea(instruccionAritmetica(operador) + " t3, t1, t2");
        guardarValor(resultado, "t3");
    }

    @Override
    public void emitirComparacion(OperadorCuarteta operador, Operando izquierda,
            Operando derecha, Operando resultado) {
        asegurarUnidad();
        if (esDecimal(izquierda) || esDecimal(derecha)) {
            emitirComparacionDecimal(operador, izquierda, derecha, resultado);
            return;
        }
        cargarValor(izquierda, "t1");
        cargarValor(derecha, "t2");
        switch (operador) {
            case MENOR_Q:
                linea("slt t3, t1, t2");
                break;
            case MENOR_EQ_Q:
                linea("slt t3, t2, t1");
                linea("xori t3, t3, 1");
                break;
            case MAYOR_Q:
                linea("slt t3, t2, t1");
                break;
            case MAYOR_EQ_Q:
                linea("slt t3, t1, t2");
                linea("xori t3, t3, 1");
                break;
            default:
                linea("slt t3, t1, t2");
                break;
        }
        guardarValor(resultado, "t3");
    }

    @Override
    public void emitirIgualdad(OperadorCuarteta operador, Operando izquierda,
            Operando derecha, Operando resultado) {
        asegurarUnidad();
        if (esDecimal(izquierda) || esDecimal(derecha)) {
            cargarValor(izquierda, "t1");
            linea("fmv.d.x fa0, t1");
            cargarValor(derecha, "t2");
            linea("fmv.d.x fa1, t2");
            linea("feq.d t3, fa0, fa1");
            if (operador == OperadorCuarteta.DISTINTO) {
                linea("xori t3, t3, 1");
            }
            guardarValor(resultado, "t3");
            return;
        }
        cargarValor(izquierda, "t1");
        cargarValor(derecha, "t2");
        linea("sub t3, t1, t2");
        if (operador == OperadorCuarteta.DISTINTO) {
            linea("snez t3, t3");
        } else {
            linea("seqz t3, t3");
        }
        guardarValor(resultado, "t3");
    }

    @Override
    public void emitirLogicaBinaria(OperadorCuarteta operador, Operando izquierda,
            Operando derecha, Operando resultado) {
        asegurarUnidad();
        cargarValor(izquierda, "t1");
        cargarValor(derecha, "t2");
        linea((operador == OperadorCuarteta.AND ? "and" : "or") + " t3, t1, t2");
        guardarValor(resultado, "t3");
    }

    @Override
    public void emitirNegacion(OperadorCuarteta operador, Operando operando,
            Operando resultado) {
        asegurarUnidad();
        cargarValor(operando, "t1");
        if (operador == OperadorCuarteta.NOT) {
            linea("seqz t3, t1");
        } else {
            linea("neg t3, t1");
        }
        guardarValor(resultado, "t3");
    }

    @Override
    public void emitirIncrementoDecremento(OperadorCuarteta operador, Operando objetivo,
            Operando resultado) {
        asegurarUnidad();
        cargarValor(objetivo, "t1");
        linea((operador == OperadorCuarteta.INCREMENTO ? "addi t3, t1, 1" : "addi t3, t1, -1"));
        guardarValor(objetivo, "t3");
        if (resultado != null) {
            guardarValor(resultado, "t3");
        }
    }

    @Override
    public void emitirEtiqueta(Operando etiqueta) {
        String texto = etiqueta.getTexto();
        String unidadActual = ambiente.getUnidadActual();
        if (unidadActual != null && unidadActual.equals(texto)
                && !unidadActual.equals(unidadEnCurso)) {
            cerrarUnidad();
            abrirUnidad(unidadActual);
        } else {
            asegurarUnidad();
            unidad.append(texto).append(":\n");
        }
    }

    @Override
    public void emitirSalto(Operando etiqueta) {
        asegurarUnidad();
        linea("j " + etiqueta.getTexto());
    }

    @Override
    public void emitirCondicional(OperadorCuarteta operador, Operando condicion,
            Operando etiqueta) {
        asegurarUnidad();
        cargarValor(condicion, "t1");
        linea("bnez t1, " + etiqueta.getTexto());
    }

    @Override
    public void emitirImprimir(Operando valor, boolean conSaltoLinea) {
        asegurarUnidad();
        if (valor != null) {
            String rutina = RuntimeZ.rutinaImpresion(valor.getTipo());
            if (rutina != null) {
                cargarValor(valor, "a0");
                linea("call " + rutina);
            }
        }
        if (conSaltoLinea) {
            linea("call " + RuntimeZ.imprimirSaltoDeLinea());
        }
    }

    @Override
    public void emitirLeer(Operando destino) {
        asegurarUnidad();
        if (destino == null || destino.getTipo() == null) {
            return;
        }
        // Las cadenas necesitan un buffer propio: se reserva en el heap y se
        // pasa en a0 (direccion) con el tamaño maximo en a1.
        if (destino.getTipo().getTipoDato() == TipoDato.CADENA) {
            linea("li a0, " + TAMAÑO_BUFFER_CADENA);
            linea("call z_alloc");
            linea("li a1, " + TAMAÑO_BUFFER_CADENA);
            linea("call z_leer_cadena");
            guardarValor(destino, "a0");
            return;
        }
        String rutina = RuntimeZ.rutinaLectura(destino.getTipo());
        if (rutina == null) {
            return;
        }
        linea("call " + rutina);
        guardarValor(destino, "a0");
    }

    @Override
    public void emitirPunteroInicio(Operando destino, Operando cantidad) {
        asegurarUnidad();
        int bytes = bytesDeObjeto(destino, cantidad);
        linea("li a0, " + bytes);
        linea("call z_alloc");
        guardarValor(destino, "a0");
    }

    @Override
    public void emitirAccesoIndice(Operando base, Operando indice, Operando destino) {
        asegurarUnidad();
        // El indice primero: su carga puede usar t6 como registro de trabajo.
        cargarValor(indice, "t2");
        cargarValor(base, "t1");
        int tamaño = tamañoElemento(destino);
        linea("li t3, " + tamaño);
        linea("mul t2, t2, t3");
        linea("add t1, t1, t2");
        if (destino instanceof com.ronaldo.cd3.compiler.api.modelos.ir.operando.OperandoIndice) {
            return;
        }
        cargarDesdeDireccion("t3", "t1", tamañoAlmacen(destino));
        guardarValor(destino, "t3");
    }

    @Override
    public void emitirParametro(Operando operando) {
        parametrosPendientes.add(operando);
    }

    @Override
    public void emitirLlamada(Operando funcion, Operando resultado) {
        asegurarUnidad();
        int total = parametrosPendientes.size();
        int registros = Math.min(total, 8);
        int extra = total - registros;
        if (extra > 0) {
            linea("addi sp, sp, -" + (extra * TAMAÑO_SLOT));
        }
        for (int i = 0; i < total; i++) {
            Operando argumento = parametrosPendientes.get(i);
            if (i < registros) {
                cargarValor(argumento, "a" + i);
            } else {
                cargarValor(argumento, "t1");
                linea("sd t1, " + ((i - registros) * TAMAÑO_SLOT) + "(sp)");
            }
        }
        if (funcion != null && funcion.getTexto() != null) {
            linea("call " + funcion.getTexto());
        }
        if (extra > 0) {
            linea("addi sp, sp, " + (extra * TAMAÑO_SLOT));
        }
        guardarResultado(resultado);
        parametrosPendientes.clear();
    }

    private void guardarResultado(Operando resultado) {
        if (resultado == null) {
            return;
        }
        if (esStructPorValor(resultado)) {
            int tamaño = ((TipoStructura) resultado.getTipo()).getTamañoHeap();
            int palabras = min((tamaño + 7) / 8, 2);
            for (int i = 0; i < palabras; i++) {
                linea("sd a" + i + ", " + offsetPalabra(resultado, i) + "(fp)");
            }
            return;
        }
        guardarValor(resultado, "a0");
    }

    @Override
    public void emitirLlamadaVirtual(Operando receptor, int slot, Operando resultado) {
        asegurarUnidad();
        int total = parametrosPendientes.size();
        int registros = Math.min(total, 8);
        int extra = total - registros;
        if (extra > 0) {
            linea("addi sp, sp, -" + (extra * TAMAÑO_SLOT));
        }
        for (int i = 0; i < total; i++) {
            Operando argumento = parametrosPendientes.get(i);
            if (i < registros) {
                cargarValor(argumento, "a" + i);
            } else {
                cargarValor(argumento, "t1");
                linea("sd t1, " + ((i - registros) * TAMAÑO_SLOT) + "(sp)");
            }
        }
        // despacho dinamico: t0 = objeto->vtable; t0 = vtable[slot]; jalr
        // El receptor es el argumento 0, por lo que ya esta en a0 si hay
        // parametros pendientes; en caso contrario se recarga.
        if (total > 0) {
            linea("mv t0, a0");
        } else if (receptor != null) {
            cargarValor(receptor, "t0");
        }
        linea("ld t0, 0(t0)");
        linea("ld t0, " + (slot * TAMAÑO_SLOT) + "(t0)");
        linea("jalr t0");
        if (extra > 0) {
            linea("addi sp, sp, " + (extra * TAMAÑO_SLOT));
        }
        guardarResultado(resultado);
        parametrosPendientes.clear();
    }

    @Override
    public void emitirFijarVtable(Operando objeto, String nombreClase) {
        asegurarUnidad();
        if (objeto == null || nombreClase == null) {
            return;
        }
        String offset = offset(objeto);
        linea("ld t6, " + offset + "(fp)");
        linea("la t1, __vtable_" + nombreClase);
        linea("sd t1, 0(t6)");
    }

    @Override
    public void emitirRetorno(Operando valor) {
        asegurarUnidad();
        if (valor != null) {
            if (esStructPorValor(valor)) {
                // struct por valor: se retorna palabra por palabra en a0/a1
                int tamaño = ((TipoStructura) valor.getTipo()).getTamañoHeap();
                int palabras = min((tamaño + 7) / 8, 2);
                for (int i = 0; i < palabras; i++) {
                    linea("ld t1, " + offsetPalabra(valor, i) + "(fp)");
                    linea("mv a" + i + ", t1");
                }
            } else {
                cargarValor(valor, "a0");
            }
        }
        if (unidadEnCurso != null) {
            linea("j __epilogo_" + unidadEnCurso);
        }
    }

    private boolean esStructPorValor(Operando operando) {
        Tipo tipo = (operando != null) ? operando.getTipo() : null;
        return tipo instanceof TipoStructura && !((TipoStructura) tipo).esPorReferencia();
    }

    private static int min(int a, int b) {
        return (a < b) ? a : b;
    }

    private String offsetPalabra(Operando operando, int palabra) {
        int offset = Integer.parseInt(offset(operando));
        return String.valueOf(offset + palabra * TAMAÑO_SLOT);
    }

    // ------------------------------------------------------------------
    // Carga y almacenamiento de operandos
    // ------------------------------------------------------------------

    private void cargarValor(Operando operando, String registro) {
        if (operando == null) {
            return;
        }
        if (operando instanceof com.ronaldo.cd3.compiler.api.modelos.ir.operando.OperandoLiteral) {
            cargarLiteral((com.ronaldo.cd3.compiler.api.modelos.ir.operando.OperandoLiteral) operando, registro);
        } else if (operando instanceof com.ronaldo.cd3.compiler.api.modelos.ir.operando.OperandoAtributo
                || operando instanceof com.ronaldo.cd3.compiler.api.modelos.ir.operando.OperandoIndice) {
            cargarDireccion(operando, "t6");
            cargarDesdeDireccion(registro, "t6", tamañoAlmacen(operando));
        } else {
            linea("ld " + registro + ", " + offset(operando) + "(fp)");
        }
    }

    private void guardarValor(Operando destino, String registro) {
        if (destino == null) {
            return;
        }
        if (destino instanceof com.ronaldo.cd3.compiler.api.modelos.ir.operando.OperandoLiteral) {
            return;
        }
        if (destino instanceof com.ronaldo.cd3.compiler.api.modelos.ir.operando.OperandoAtributo
                || destino instanceof com.ronaldo.cd3.compiler.api.modelos.ir.operando.OperandoIndice) {
            cargarDireccion(destino, "t6");
            guardarEnDireccion(registro, "t6", tamañoAlmacen(destino));
            return;
        }
        linea("sd " + registro + ", " + offset(destino) + "(fp)");
    }

    private void cargarDireccion(Operando operando, String registro) {
        if (operando instanceof com.ronaldo.cd3.compiler.api.modelos.ir.operando.OperandoAtributo) {
            com.ronaldo.cd3.compiler.api.modelos.ir.operando.OperandoAtributo atributo
                    = (com.ronaldo.cd3.compiler.api.modelos.ir.operando.OperandoAtributo) operando;
            baseDeCampo(atributo.getBase(), registro);
            if (atributo.getOffset() != 0) {
                linea("addi " + registro + ", " + registro + ", " + atributo.getOffset());
            }
            return;
        }
        if (operando instanceof com.ronaldo.cd3.compiler.api.modelos.ir.operando.OperandoIndice) {
            com.ronaldo.cd3.compiler.api.modelos.ir.operando.OperandoIndice indice
                    = (com.ronaldo.cd3.compiler.api.modelos.ir.operando.OperandoIndice) operando;
            // El indice se calcula primero porque su carga puede usar el
            // registro del marco de trabajo (t6); la base se carga despues
            // en "registro" y no debe verse pisada.
            cargarValor(indice.getIndice(), "t2");
            cargarValor(indice.getBase(), registro);
            int tamaño = tamañoElementoIndice(indice);
            linea("li t4, " + tamaño);
            linea("mul t2, t2, t4");
            linea("add " + registro + ", " + registro + ", t2");
            return;
        }
        if (operando instanceof com.ronaldo.cd3.compiler.api.modelos.ir.operando.OperandoLiteral) {
            com.ronaldo.cd3.compiler.api.modelos.ir.operando.OperandoLiteral literal
                    = (com.ronaldo.cd3.compiler.api.modelos.ir.operando.OperandoLiteral) operando;
            if (literal.getEtiqueta() != null) {
                linea("la " + registro + ", " + literal.getEtiqueta());
            }
            return;
        }
        linea("addi " + registro + ", fp, " + offset(operando));
    }

    /**
     * Direccion de la base de un acceso a campo. Si la base es un struct por
     * valor (estructura Y en el frame) la direccion es fp+offset; si es una
     * referencia (clase Z, puntero) se carga su valor.
     */
    private void baseDeCampo(Operando base, String registro) {
        if (base == null) {
            return;
        }
        if (esPorValor(base)) {
            linea("addi " + registro + ", fp, " + offset(base));
        } else {
            cargarValor(base, registro);
        }
    }

    private boolean esPorValor(Operando operando) {
        Tipo tipo = (operando != null) ? operando.getTipo() : null;
        if (tipo instanceof TipoStructura) {
            return !((TipoStructura) tipo).esPorReferencia();
        }
        return false;
    }

    private void cargarLiteral(com.ronaldo.cd3.compiler.api.modelos.ir.operando.OperandoLiteral literal,
            String registro) {
        if (literal.getEtiqueta() != null) {
            linea("la " + registro + ", " + literal.getEtiqueta());
            if (esDecimal(literal)) {
                linea("ld " + registro + ", 0(" + registro + ")");
            }
            return;
        }
        linea("li " + registro + ", " + valorDeLiteral(literal));
    }

    // ------------------------------------------------------------------
    // Utilidades
    // ------------------------------------------------------------------

    private void linea(String instruccion) {
        unidad.append("    ").append(instruccion).append("\n");
    }

    private void cargarDesdeDireccion(String registro, String direccion, int tamaño) {
        linea(cargaInstruccion(tamaño) + " " + registro + ", 0(" + direccion + ")");
    }

    private void guardarEnDireccion(String registro, String direccion, int tamaño) {
        linea(almacenInstruccion(tamaño) + " " + registro + ", 0(" + direccion + ")");
    }

    private static String cargaInstruccion(int tamaño) {
        if (tamaño <= 1) {
            return "lb";
        }
        if (tamaño <= 4) {
            return "lw";
        }
        return "ld";
    }

    private static String almacenInstruccion(int tamaño) {
        if (tamaño <= 1) {
            return "sb";
        }
        if (tamaño <= 4) {
            return "sw";
        }
        return "sd";
    }

    private static String instruccionAritmetica(OperadorCuarteta operador) {
        switch (operador) {
            case SUMA:
                return "add";
            case RESTA:
                return "sub";
            case MULTIPLICACION:
                return "mul";
            case DIVISION:
                return "div";
            case MODULO:
                return "rem";
            default:
                return "add";
        }
    }

    private void emitirAritmeticaDecimal(OperadorCuarteta operador, Operando izquierda,
            Operando derecha, Operando resultado) {
        cargarValor(izquierda, "t1");
        linea("fmv.d.x fa0, t1");
        cargarValor(derecha, "t2");
        linea("fmv.d.x fa1, t2");
        String instruccion;
        switch (operador) {
            case SUMA:
                instruccion = "fadd.d";
                break;
            case RESTA:
                instruccion = "fsub.d";
                break;
            case MULTIPLICACION:
                instruccion = "fmul.d";
                break;
            case DIVISION:
                instruccion = "fdiv.d";
                break;
            case MODULO:
                instruccion = "frem.d";
                break;
            default:
                instruccion = "fadd.d";
                break;
        }
        linea(instruccion + " fa2, fa0, fa1");
        linea("fmv.x.d t3, fa2");
        guardarValor(resultado, "t3");
    }

    private void emitirComparacionDecimal(OperadorCuarteta operador, Operando izquierda,
            Operando derecha, Operando resultado) {
        cargarValor(izquierda, "t1");
        linea("fmv.d.x fa0, t1");
        cargarValor(derecha, "t2");
        linea("fmv.d.x fa1, t2");
        switch (operador) {
            case MENOR_Q:
                linea("flt.d t3, fa0, fa1");
                break;
            case MENOR_EQ_Q:
                linea("fle.d t3, fa0, fa1");
                break;
            case MAYOR_Q:
                linea("flt.d t3, fa1, fa0");
                break;
            case MAYOR_EQ_Q:
                linea("fle.d t3, fa1, fa0");
                break;
            default:
                linea("flt.d t3, fa0, fa1");
                break;
        }
        guardarValor(resultado, "t3");
    }

    private static boolean esDecimal(Operando operando) {
        return operando != null && operando.getTipo() != null
                && operando.getTipo().getTipoDato() == TipoDato.DECIMAL;
    }

    private static boolean esEntero(Operando operando) {
        if (operando == null || operando.getTipo() == null) {
            return false;
        }
        TipoDato dato = operando.getTipo().getTipoDato();
        return dato == TipoDato.ENTERO || dato == TipoDato.CHAR || dato == TipoDato.BOOLEAN;
    }

    private static int tamañoElemento(Operando destino) {
        if (destino instanceof com.ronaldo.cd3.compiler.api.modelos.ir.operando.OperandoIndice) {
            return tamañoElementoIndice(
                    (com.ronaldo.cd3.compiler.api.modelos.ir.operando.OperandoIndice) destino);
        }
        return tamañoAlmacen(destino);
    }

    private static int tamañoElementoIndice(
            com.ronaldo.cd3.compiler.api.modelos.ir.operando.OperandoIndice indice) {
        int tamaño = indice.getTamañoElemento();
        if (tamaño > 0) {
            return tamaño;
        }
        Operando base = indice.getBase();
        if (base != null && base.getTipo() instanceof TipoArreglo) {
            Tipo elemento = ((TipoArreglo) base.getTipo()).getTipoBase();
            if (elemento != null) {
                if (elemento.esPorReferencia()) {
                    return 8;
                }
                int bytes = elemento.tamañoBytes();
                return (bytes <= 4) ? 4 : 8;
            }
        }
        return tamañoAlmacen(indice);
    }

    private static int tamañoAlmacen(Operando operando) {
        if (operando == null || operando.getTipo() == null) {
            return 8;
        }
        if (operando.getTipo().esPorReferencia()) {
            return 8;
        }
        int tamaño = operando.getTipo().tamañoBytes();
        if (tamaño <= 1) {
            return 1;
        }
        if (tamaño <= 4) {
            return 4;
        }
        return 8;
    }

    private int bytesDeObjeto(Operando destino, Operando cantidad) {
        if (destino == null || destino.getTipo() == null) {
            return 8;
        }
        if (destino.getTipo() instanceof TipoArreglo) {
            TipoArreglo arreglo = (TipoArreglo) destino.getTipo();
            Tipo base = arreglo.getTipoBase();
            int tamañoBase = (base instanceof TipoStructura || base instanceof TipoArreglo)
                    ? 8
                    : base.tamañoBytes();
            int cuenta = arreglo.getTotalElementos();
            if (cantidad != null && cantidad.getTipo() != null
                    && cantidad.getTipo().getTipoDato() == TipoDato.ENTERO
                    && cantidad instanceof com.ronaldo.cd3.compiler.api.modelos.ir.operando.OperandoLiteral) {
                cuenta = (int) valorDeLiteral(
                        (com.ronaldo.cd3.compiler.api.modelos.ir.operando.OperandoLiteral) cantidad);
            }
            return Math.max(1, cuenta) * tamañoBase;
        }
        if (destino.getTipo() instanceof TipoStructura) {
            return ((TipoStructura) destino.getTipo()).getTamañoHeap();
        }
        return 8;
    }

    private static long valorDeLiteral(
            com.ronaldo.cd3.compiler.api.modelos.ir.operando.OperandoLiteral literal) {
        String texto = literal.getTexto();
        TipoOperando categoria = literal.getCategoria();
        if (categoria == TipoOperando.BOOLEANO_VERDADERO) {
            return 1;
        }
        if (categoria == TipoOperando.BOOLEANO_FALSO) {
            return 0;
        }
        if (categoria == TipoOperando.NULO) {
            return 0;
        }
        if (categoria == TipoOperando.CONSTANTE_CARACTER) {
            String limpio = texto.replace("'", "");
            if (limpio.startsWith("\\")) {
                switch (limpio) {
                    case "\\n":
                        return '\n';
                    case "\\t":
                        return '\t';
                    case "\\r":
                        return '\r';
                    case "\\0":
                        return 0;
                    default:
                        return limpio.isEmpty() ? 0 : limpio.charAt(1);
                }
            }
            return limpio.isEmpty() ? 0 : limpio.charAt(0);
        }
        try {
            return Long.parseLong(texto.trim());
        } catch (NumberFormatException ex) {
            try {
                return (long) Double.parseDouble(texto.trim());
            } catch (NumberFormatException ex2) {
                return 0;
            }
        }
    }
}
