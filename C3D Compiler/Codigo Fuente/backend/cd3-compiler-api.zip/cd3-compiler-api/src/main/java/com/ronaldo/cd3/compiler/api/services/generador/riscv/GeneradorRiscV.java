package com.ronaldo.cd3.compiler.api.services.generador.riscv;

import com.ronaldo.cd3.compiler.api.enums.OperadorCuarteta;
import com.ronaldo.cd3.compiler.api.enums.TipoDato;
import com.ronaldo.cd3.compiler.api.enums.TipoOperando;
import com.ronaldo.cd3.compiler.api.modelos.cuarteta.Cuarteta;
import com.ronaldo.cd3.compiler.api.modelos.cuarteta.ListaCuartetas;
import com.ronaldo.cd3.compiler.api.modelos.ir.MotorIR;
import com.ronaldo.cd3.compiler.api.modelos.ir.PoolLiterales;
import java.util.List;
import java.util.Map;

/**
 * Generador de codigo RISC-V (RV64). Recorre el IR con un {@link EmisorRiscV} y
 * ensambla la salida final: seccion .data (literales del pool), .text (con un
 * punto de entrada main) y las rutinas de soporte de {@link RuntimeRiscV}.
 */
public class GeneradorRiscV {

    private static final int DIRECCION_INICIO_HEAP = 0x10040000;

    public String generar(ListaCuartetas cuartetas) {
        if (cuartetas == null || cuartetas.getCuartetas().isEmpty()) {
            return "";
        }

        MotorIR motor = new MotorIR(cuartetas);
        EmisorRiscV emisor = new EmisorRiscV(motor.getAmbiente());
        motor.recorrer(emisor);
        emisor.finalizar();

        StringBuilder codigo = new StringBuilder();
        codigo.append(seccionDatos(motor.getAmbiente().getPoolLiterales()));
        codigo.append(seccionVTables(cuartetas));
        codigo.append(".text\n");
        codigo.append(".globl main\n");
        codigo.append("main:\n");
        String cuerpo = emisor.getCuerpo();
        String entrada = buscarEntrada(cuartetas);
        if (entrada != null) {
            // La unidad de entrada del usuario puede llamarse "main" (Pig). Se
            // renombra para no colisionar con el punto de entrada del SO.
            String real = "__entrada_" + entrada;
            cuerpo = cuerpo.replaceAll(
                    "(?m)^" + java.util.regex.Pattern.quote(entrada) + ":\\s*$",
                    real + ":");
            codigo.append("    call ").append(real).append("\n");
        }
        codigo.append("    li a7, 10\n");
        codigo.append("    ecall\n\n");
        codigo.append(cuerpo);
        codigo.append(RuntimeRiscV.codigo());
        return codigo.toString();
    }

    private String seccionDatos(PoolLiterales pool) {
        StringBuilder datos = new StringBuilder();
        datos.append(".data\n");
        datos.append("__z_nulo: .asciz \"(nulo)\"\n");
        datos.append("__z_heap: .dword ").append(DIRECCION_INICIO_HEAP).append("\n");
        if (pool != null) {
            for (PoolLiterales.EntradaLiteral entrada : pool.getEntradas()) {
                datos.append(".align ").append(alineacionExponente(entrada.getAlineacion())).append("\n");
                datos.append(entrada.getEtiqueta()).append(": ");
                if (esCadena(entrada)) {
                    datos.append(".asciz ").append(entrada.getValor());
                } else {
                    datos.append(".double ").append(entrada.getValor());
                }
                datos.append("\n");
            }
        }
        return datos.toString();
    }

    private String seccionVTables(ListaCuartetas cuartetas) {
        com.ronaldo.cd3.compiler.api.modelos.vtable.TablaVTables vTables
                = (cuartetas != null) ? cuartetas.getVTables() : null;
        if (vTables == null || vTables.getVTables().isEmpty()) {
            return "";
        }
        StringBuilder datos = new StringBuilder();
        for (Map.Entry<String, List<com.ronaldo.cd3.compiler.api.modelos.vtable.EntradaVTable>> entrada
                : vTables.getVTables().entrySet()) {
            List<com.ronaldo.cd3.compiler.api.modelos.vtable.EntradaVTable> tabla
                    = entrada.getValue();
            if (tabla == null || tabla.isEmpty()) {
                continue;
            }
            datos.append(".align 3\n");
            datos.append("__vtable_").append(entrada.getKey()).append(":\n");
            for (com.ronaldo.cd3.compiler.api.modelos.vtable.EntradaVTable entradaVTable
                    : tabla) {
                datos.append("    .dword ").append(entradaVTable.getEtiquetaImplementacion())
                        .append("\n");
            }
        }
        return datos.toString();
    }

    private String buscarEntrada(ListaCuartetas cuartetas) {
        String candidata = null;
        for (Cuarteta cuarteta : cuartetas.getCuartetas()) {
            if (cuarteta.getOperador() != OperadorCuarteta.ETIQUETA) {
                continue;
            }
            String etiqueta = cuarteta.getArg1();
            if (etiqueta == null
                    || cuartetas.categoriaDe(etiqueta) == TipoOperando.ETIQUETA_INTERNA) {
                continue;
            }
            if (etiqueta.equals("main")) {
                return etiqueta;
            }
            if (candidata == null && tieneMain(etiqueta)) {
                candidata = etiqueta;
            }
        }
        return candidata;
    }

    private static boolean tieneMain(String etiqueta) {
        return etiqueta.contains("_main_") || etiqueta.endsWith("main");
    }

    private static boolean esCadena(PoolLiterales.EntradaLiteral entrada) {
        return entrada.getValor() != null && entrada.getValor().trim().startsWith("\"");
    }

    private static int alineacionExponente(int alineacion) {
        int exponente = 0;
        int valor = Math.max(1, alineacion);
        while (valor > 1) {
            valor >>= 1;
            exponente++;
        }
        return exponente;
    }
}
