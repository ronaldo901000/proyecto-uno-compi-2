package com.ronaldo.cd3.compiler.api.modelos.tabla.simbolos;

import com.ronaldo.cd3.compiler.api.enums.ModificadoresAcceso;
import com.ronaldo.cd3.compiler.api.enums.RolSimbolo;
import com.ronaldo.cd3.compiler.api.modelos.tipos.Tipo;
import java.util.List;

/**
 *
 * @author ronaldo
 */
public class SimboloFuncion extends Simbolo {

    private final List<SimboloParametro> parametros;
    private int tamañoFrame;
    private String etiquetaInicio;
    private String nombreClase;
    private boolean esMetodo;
    private ModificadoresAcceso modAcceso = ModificadoresAcceso.DEFAULT;

    public SimboloFuncion(String id, Tipo tipoRetorno,
            List<SimboloParametro> parametros,
            int tamañoFrame, String etiquetaInicio) {
        super(id, tipoRetorno, RolSimbolo.FUNCION);
        this.parametros = parametros;
        this.tamañoFrame = tamañoFrame;
        this.etiquetaInicio = etiquetaInicio;
        this.nombreClase = null;
        this.esMetodo = false;
    }

    public List<SimboloParametro> getParametros() {
        return parametros;
    }

    public Tipo getTipoRetorno() {
        return this.getTipo();
    }

    public void setTipoRetorno(Tipo tipoRetorno) {
        this.setTipo(tipoRetorno);
    }

    public int getTamañoFrame() {
        return tamañoFrame;
    }

    public void setTamañoFrame(int tamañoFrame) {
        this.tamañoFrame = tamañoFrame;
    }

    public String getEtiquetaInicio() {
        return etiquetaInicio;
    }

    public void setEtiquetaInicio(String etiquetaInicio) {
        this.etiquetaInicio = etiquetaInicio;
    }

    public String getNombreClase() {
        return nombreClase;
    }

    public void setNombreClase(String nombreClase) {
        this.nombreClase = nombreClase;
    }

    public boolean esMetodo() {
        return esMetodo;
    }

    public void setEsMetodo(boolean esMetodo) {
        this.esMetodo = esMetodo;
    }

    public ModificadoresAcceso getModAcceso() {
        return modAcceso;
    }

    public void setModAcceso(ModificadoresAcceso modAcceso) {
        this.modAcceso = modAcceso;
    }

    
}
