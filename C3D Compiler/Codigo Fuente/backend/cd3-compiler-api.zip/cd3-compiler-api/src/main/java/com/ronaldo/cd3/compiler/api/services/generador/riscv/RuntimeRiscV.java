package com.ronaldo.cd3.compiler.api.services.generador.riscv;

/**
 * Rutinas de soporte en ensamblador RISC-V (RV64) que el codigo generado
 * invoca. Usan las llamadas al sistema de RARS/MARS.
 */
public final class RuntimeRiscV {

    private RuntimeRiscV() {
    }

    public static String codigo() {
        return ""
                + "z_print_entero:\n"
                + "    li a7, 1\n"
                + "    ecall\n"
                + "    ret\n"
                + "z_print_cadena:\n"
                + "    li a7, 4\n"
                + "    ecall\n"
                + "    ret\n"
                + "z_print_caracter:\n"
                + "    li a7, 11\n"
                + "    ecall\n"
                + "    ret\n"
                + "z_print_booleano:\n"
                + "    li a7, 1\n"
                + "    ecall\n"
                + "    ret\n"
                + "z_print_nulo:\n"
                + "    la a0, __z_nulo\n"
                + "    li a7, 4\n"
                + "    ecall\n"
                + "    ret\n"
                + "z_print_decimal:\n"
                + "    fmv.d.x fa0, a0\n"
                + "    li a7, 3\n"
                + "    ecall\n"
                + "    ret\n"
                + "z_print_salto:\n"
                + "    li a0, 10\n"
                + "    li a7, 11\n"
                + "    ecall\n"
                + "    ret\n"
                + "z_leer_entero:\n"
                + "    li a7, 5\n"
                + "    ecall\n"
                + "    ret\n"
                + "z_leer_decimal:\n"
                + "    li a7, 7\n"
                + "    ecall\n"
                + "    fmv.x.d a0, fa0\n"
                + "    ret\n"
                + "z_leer_caracter:\n"
                + "    li a7, 12\n"
                + "    ecall\n"
                + "    ret\n"
                + "z_leer_cadena:\n"
                + "    li a7, 8\n"
                + "    ecall\n"
                + "    ret\n"
                + "z_alloc:\n"
                + "    mv a1, a0\n"
                + "    addi a1, a1, 7\n"
                + "    andi a1, a1, -8\n"
                + "    la t0, __z_heap\n"
                + "    ld a0, 0(t0)\n"
                + "    add t2, a0, a1\n"
                + "    sd t2, 0(t0)\n"
                + "    ret\n";
    }
}
