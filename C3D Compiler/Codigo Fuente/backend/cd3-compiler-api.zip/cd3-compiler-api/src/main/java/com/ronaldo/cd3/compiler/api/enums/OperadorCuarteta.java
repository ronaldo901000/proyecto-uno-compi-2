package com.ronaldo.cd3.compiler.api.enums;

/**
 *
 * @author ronaldo
 */
public enum OperadorCuarteta {
    ASIGNACION,
    SUMA,
    RESTA,
    MULTIPLICACION,
    DIVISION,
    MODULO,
    MENOR_Q,
    MENOR_EQ_Q,
    MAYOR_Q,
    MAYOR_EQ_Q,
    IGUAL,
    DISTINTO,
    AND,
    OR,
    NEGATIVO_UNARIO,
    NOT,
    INCREMENTO,
    DECREMENTO,
    ETIQUETA,
    GOTO,
    IF_VERDADERO,
    PARAMETRO,
    LLAMADA,
    LLAMADA_VIRTUAL,
    FIJAR_VTABLE,
    RETORNO,
    IMPRIMIR,
    LEER,
    PUNTERO_INICIO,
    ACCESO_INDICE
}