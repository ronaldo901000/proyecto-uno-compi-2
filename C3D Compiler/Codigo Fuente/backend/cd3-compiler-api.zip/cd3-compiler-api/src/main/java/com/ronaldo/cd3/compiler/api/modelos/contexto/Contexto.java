package com.ronaldo.cd3.compiler.api.modelos.contexto;

import com.ronaldo.cd3.compiler.api.dtos.error.analisis.ErrorSemantico;
import com.ronaldo.cd3.compiler.api.modelos.tabla.TablaSimbolos;
import com.ronaldo.cd3.compiler.api.modelos.tabla.simbolos.SimboloClase;
import com.ronaldo.cd3.compiler.api.modelos.tipos.TablaTipos;
import com.ronaldo.cd3.compiler.api.modelos.tipos.Tipo;
import java.util.ArrayDeque;
import java.util.ArrayList;
import java.util.List;

/**
 *
 * @author ronaldo
 */
public class Contexto {

    private TablaTipos tablaTipos;
    private TablaSimbolos tablaSimbolos;
    private TablaSimbolos ambito;
    private List<ErrorSemantico> errores;
    private String ruta;
    private Tipo tipoRetornoActual;
    private SimboloClase claseActual;
    private int contadorCiclos;
    private boolean dentroSwitch;
    private boolean esLenguajeZ;
    private final ArrayDeque<String> pilaEtiquetasContinuar = new ArrayDeque<>();
    private final ArrayDeque<String> pilaEtiquetasRomper = new ArrayDeque<>();
    private String rutaPaquete;

    public Contexto(TablaTipos tablaTipos, TablaSimbolos tablaSimbolos,
            TablaSimbolos ambito) {
        this.tablaTipos = tablaTipos;
        this.tablaSimbolos = tablaSimbolos;
        this.ambito = (ambito != null) ? ambito : tablaSimbolos;
        this.errores = new ArrayList<>();
    }

    public void setEsLenguajeZ(boolean esLenguajeZ) {
        this.esLenguajeZ = esLenguajeZ;
    }

    public boolean esLenguajeZ() {
        return esLenguajeZ;
    }

    public TablaTipos getTablaTipos() {
        return tablaTipos;
    }

    public void setTablaTipos(TablaTipos tablaTipos) {
        this.tablaTipos = tablaTipos;
    }

    public TablaSimbolos getTablaSimbolos() {
        return tablaSimbolos;
    }

    public void setTablaSimbolos(TablaSimbolos tablaSimbolos) {
        this.tablaSimbolos = tablaSimbolos;
    }

    public TablaSimbolos getAmbito() {
        return ambito;
    }

    public void setAmbito(TablaSimbolos ambito) {
        this.ambito = ambito;
    }

    public TablaSimbolos nuevoAmbito(String nombre) {
        TablaSimbolos anterior = this.ambito;
        this.ambito = this.ambito.nuevoAmbito(nombre);
        return anterior;
    }

    public void restaurarAmbito(TablaSimbolos anterior) {
        this.ambito = anterior;
    }

    public List<ErrorSemantico> getErrores() {
        return errores;
    }

    public boolean hayErrores() {
        return !errores.isEmpty();
    }

    public String getRuta() {
        return ruta;
    }

    public void setRuta(String ruta) {
        this.ruta = ruta;
    }

    public void agregarError(int fila, int columna, String lexema, String descripcion) {
        this.errores.add(new ErrorSemantico(fila, columna, lexema, descripcion, this.ruta));
    }

    public Tipo getTipoRetornoActual() {
        return tipoRetornoActual;
    }

    public void setTipoRetornoActual(Tipo tipoRetornoActual) {
        this.tipoRetornoActual = tipoRetornoActual;
    }

    public SimboloClase getClaseActual() {
        return claseActual;
    }

    public void setClaseActual(SimboloClase claseActual) {
        this.claseActual = claseActual;
    }

    public void entrarCiclo() {
        this.contadorCiclos++;
    }

    public void salirCiclo() {
        if (this.contadorCiclos > 0) {
            this.contadorCiclos--;
        }
    }

    public boolean dentroCiclo() {
        return this.contadorCiclos > 0;
    }

    public boolean dentroDeSwitch() {
        return dentroSwitch;
    }

    public void setdentroDeSwitch(boolean estaDentroElegir) {
        this.dentroSwitch = estaDentroElegir;
    }

    public void entrarNivelGeneracionCiclo(String etiquetaContinuar, String etiquetaRomper) {
        this.pilaEtiquetasContinuar.push(etiquetaContinuar);
        this.pilaEtiquetasRomper.push(etiquetaRomper);
    }

    public void salirNivelGeneracionCiclo() {
        if (!this.pilaEtiquetasContinuar.isEmpty()) {
            this.pilaEtiquetasContinuar.pop();
        }
        if (!this.pilaEtiquetasRomper.isEmpty()) {
            this.pilaEtiquetasRomper.pop();
        }
    }

    public String getEtiquetaContinuarActual() {
        return this.pilaEtiquetasContinuar.peek();
    }

    public String getEtiquetaRomperActual() {
        return this.pilaEtiquetasRomper.peek();
    }

    public String getRutaPaquete() {
        return rutaPaquete;
    }

    public void setRutaPaquete(String rutaPaquete) {
        this.rutaPaquete = rutaPaquete;
    }

}
